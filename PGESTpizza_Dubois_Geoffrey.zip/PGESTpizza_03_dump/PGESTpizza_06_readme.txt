Mise en place de la base de donnée:

1- ouvrir le terminal mysql
2- taper : "CREATE DATABASE IF NOT EXISTS ma_base"
3- puis taper mysql < scriptBase4.0.sql
4- Enfin taper mysql < DataDev3.0.sql

La base de données est prête a être utilisé.