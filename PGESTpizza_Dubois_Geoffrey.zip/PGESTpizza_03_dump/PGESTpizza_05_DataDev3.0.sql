-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: db_pizza
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `address`
--

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
INSERT INTO `address` VALUES (1,'13010','rue des pierre',213,'0605060506'),(2,'13007','rue des caillou',230,'0605060506'),(3,'13008','rue des papier',11,'0605060506'),(4,'13011','rue des ciseaux',65,'0491424242'),(5,'13010','rue des trolls',24,'0491523212'),(6,'13005','rue des puits',42,'0706050403'),(7,'13004','rue des fauves',532,'0694959494'),(8,'13004','boulevard des airs',321,'0491878979'),(9,'13010','bourlevard des montagnes',2,'049123365412'),(10,'13011','boulevard des gens',24,'0491523212'),(11,'13013','boulevard des turcs',47,'0706050403'),(12,'13012','impasse des tulipes',37,'0491523212'),(13,'13011','impasse des roses',98,'0605060506'),(14,'13010','impasse des coquelicots',73,'049123365412'),(15,'13012','allées des rails',37,'0303030303');
/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `bill`
--

LOCK TABLES `bill` WRITE;
/*!40000 ALTER TABLE `bill` DISABLE KEYS */;
INSERT INTO `bill` VALUES (1,30.000,'CB',1,1),(2,20.100,'paypal',1,2),(3,10.900,'espece',1,3),(4,8.500,'cheque',0,4);
/*!40000 ALTER TABLE `bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (14,'geoffrey','d','123','2020-12-10',12,'mail1@oc.com',0),(15,'gaetan','d','123','2019-11-10',1,'mail2@oc.com',1),(16,'gwenaelle','d','123','2018-01-19',2,'mail3@oc.com',0),(17,'lila','m','123','2019-07-06',3,'mail4@oc.com',1),(18,'ludovic','d','123','2020-03-06',4,'mail5@oc.com',0),(19,'eddie','l','123','2020-09-16',5,'mail6@oc.com',1),(20,'mathieu','c','123','2020-06-24',6,'mail7@oc.com',1),(21,'kevin','b','123','2019-03-21',7,'mail8@oc.com',1),(22,'celia','d','123','2019-08-29',8,'mail9@oc.com',1),(23,'mylene','f','123','2019-03-03',9,'mail10@oc.com',0),(24,'aida','h','123','2018-04-24',10,'mail11@oc.com',0),(25,'michael','l','123','2018-01-12',11,'mail12@oc.com',0),(26,'remi','t','123','2019-06-05',13,'mail13@oc.com',1);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `delivery`
--

LOCK TABLES `delivery` WRITE;
/*!40000 ALTER TABLE `delivery` DISABLE KEYS */;
INSERT INTO `delivery` VALUES (1,1,'livree',3,'2020-03-12 00:00:00'),(2,2,'en livraison',3,'2020-01-27 00:00:00'),(3,3,'en livraison',3,'2019-03-02 00:00:00'),(4,4,'en préparation',3,'2019-07-13 00:00:00'),(5,1,'livree',3,'2019-12-25 00:00:00');
/*!40000 ALTER TABLE `delivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1,1,'jhon','d','123','mail1','manager'),(2,1,'hugo','b','123','mail2','manager'),(3,2,'baptiste','g','123','mail3','deliveryMan'),(4,2,'nina','d','123','mail4','cook'),(5,3,'zoé','c','123','mail5','cook'),(6,3,'théo','f','123','mail6','cashier');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `employeepizzeria`
--

LOCK TABLES `employeepizzeria` WRITE;
/*!40000 ALTER TABLE `employeepizzeria` DISABLE KEYS */;
INSERT INTO `employeepizzeria` VALUES (1,1),(4,1),(2,2),(5,2),(3,3);
/*!40000 ALTER TABLE `employeepizzeria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `ingredient`
--

LOCK TABLES `ingredient` WRITE;
/*!40000 ALTER TABLE `ingredient` DISABLE KEYS */;
INSERT INTO `ingredient` VALUES (1,'champignon',3,1),(2,'oignon',5,2),(3,'olive',4,3),(4,'fromage',45,1),(5,'tomate',12,2),(6,'creme fraiche',10,1),(7,'poulet',12,1),(8,'jambon',21,1),(9,'coca',4,2),(10,'fanta',21,3);
/*!40000 ALTER TABLE `ingredient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `pizzeria`
--

LOCK TABLES `pizzeria` WRITE;
/*!40000 ALTER TABLE `pizzeria` DISABLE KEYS */;
INSERT INTO `pizzeria` VALUES (1,'pizza1'),(2,'pizza2'),(3,'pizza3');
/*!40000 ALTER TABLE `pizzeria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'desc',10.000,'reine','recipe1'),(2,'desc',11.000,'margarita','recipe1'),(3,NULL,12.000,'toto','recipe1'),(4,NULL,13.000,'curry','recipe1'),(5,NULL,3.000,'coca','recipe1'),(6,NULL,2.000,'fanta','recipe1'),(7,'desc',11.500,'4 fromage','recipe1');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `productingredient`
--

LOCK TABLES `productingredient` WRITE;
/*!40000 ALTER TABLE `productingredient` DISABLE KEYS */;
INSERT INTO `productingredient` VALUES (1,1),(1,2),(2,2),(1,3),(2,3),(3,3),(3,4),(4,4),(2,5),(4,5),(5,5),(3,6),(6,6),(4,7);
/*!40000 ALTER TABLE `productingredient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `purchase`
--

LOCK TABLES `purchase` WRITE;
/*!40000 ALTER TABLE `purchase` DISABLE KEYS */;
INSERT INTO `purchase` VALUES (1,14,1,'fini','2020-03-12 00:00:00',1,1,'livraison'),(2,15,2,'annulee','2020-01-27 00:00:00',2,2,'livraison'),(3,16,3,'en traitenment','2019-05-13 00:00:00',3,3,'emporter'),(4,17,1,'en attente','2019-07-12 00:00:00',4,4,'livraison');
/*!40000 ALTER TABLE `purchase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `purchaseproduct`
--

LOCK TABLES `purchaseproduct` WRITE;
/*!40000 ALTER TABLE `purchaseproduct` DISABLE KEYS */;
INSERT INTO `purchaseproduct` VALUES (1,1,1,1),(2,2,1,2),(3,3,2,1),(4,4,3,3),(5,5,1,1),(6,6,2,1);
/*!40000 ALTER TABLE `purchaseproduct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `transaction`
--

LOCK TABLES `transaction` WRITE;
/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
INSERT INTO `transaction` VALUES (1,3,1,1,'2020-10-09 00:00:00','add',1),(2,2,2,2,'2019-11-03 00:00:00','remove',2),(3,12,3,3,'2019-03-27 00:00:00','add',3),(4,12,4,1,'2020-05-24 00:00:00','add',NULL),(5,1,5,1,'2020-08-17 00:00:00','add',2),(6,1,6,1,'2019-07-09 00:00:00','add',2),(7,2,7,2,'2019-08-09 00:00:00','remove',NULL),(8,3,8,3,'2019-10-11 00:00:00','remove',1),(9,21,4,1,'2019-11-24 00:00:00','remove',1),(10,1,10,2,'2020-01-13 00:00:00','add',NULL);
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'db_pizza'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31 12:46:02
